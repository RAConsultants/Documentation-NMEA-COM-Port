GPS NMEA Parser
----------------

Provides classes to simplify parsing of GPS NMEA sentences for use with your GPS applications.

Initially built for .NET Compact Framework applications, the classes have been used later in server applications and ported to Android and python applications.