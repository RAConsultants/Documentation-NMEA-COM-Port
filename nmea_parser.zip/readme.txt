NMEA Parser page:
http://avangardo.com/software/nmea-parser.html